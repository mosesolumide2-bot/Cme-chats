# CME Chats — Flutter starter

NACES • FUOYE Chapter  
Motto: *Redefining Education Through Chemistry*

This is the initial Flutter application foundation for Android and iOS. It includes:
- Branded login and registration screens
- Student and lecturer registration requests
- Supabase Auth integration
- Supabase profile bootstrap trigger and starter RLS
- Authenticated home screen
- Firebase initialization/FCM background handler scaffold
- Text chat and voice-note recording/upload/playback UI
- LiveKit audio/video room screen and secure token Edge Function template

## Prerequisites
- Flutter stable SDK and Dart
- A Supabase project
- A Firebase project with Android and iOS apps registered
- Android Studio/Xcode for platform builds

## 1. Configure Supabase
1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Authentication settings, enable email/password and configure email confirmation.
4. Keep public sign-ups restricted to the student/lecturer flow. Promote admins manually only after identity verification.
5. Configure the app's redirect/deep-link URLs before production.

## 2. Configure Firebase Cloud Messaging
1. Create a Firebase project.
2. Register Android application using your final Android application ID.
3. Register iOS application using your final bundle ID.
4. Add Firebase platform files:
   - Android: `android/app/google-services.json`
   - iOS: `ios/Runner/GoogleService-Info.plist`
5. Run `flutterfire configure` if using FlutterFire CLI, and initialize Firebase with the generated options in `main.dart` for production.
6. Enable push notifications capability and APNs key for iOS in Firebase.
7. Implement token registration and a trusted server-side sender (Supabase Edge Function or other server). Never put Firebase service-account credentials in the app.

## 3. Run
```bash
flutter pub get
flutter run --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY
```

Use only the Supabase publishable/anon key in the client. Never embed the `service_role` key.

## Important account workflow
- A new account is created with `status = pending`.
- Student/lecturer registration does not grant administrator access.
- An authorized admin must verify identity and activate the profile.
- Promote trusted administrators manually from the Supabase SQL editor.
- The current starter now includes an initial chat/voice-note module and LiveKit call client scaffold. The admin review UI, receipt workflow, production incoming-call notification routing, call invitation/ringing flow, and full real-time message subscriptions are still pending.

## Branding assets
Place approved, separately cropped transparent/PNG logo files in `assets/branding/` and update the header widgets to display them. The supplied reference image is a combined image containing department and university marks; confirm/crop official source artwork before publication.

## Production checklist
- Add profile editing with field-level authorization.
- Add CAPTCHA/rate limits and email verification.
- Add RLS tests for every table.
- Add private Storage policies and signed URLs.
- Add audit logs for admin actions and payment approvals.
- Add FCM token registration, refresh and server-side delivery.
- Add app privacy policy, terms, account deletion and backups.
- Test on real Android and iOS devices.


## 4. Voice notes and chat setup
1. Re-run `supabase/schema.sql` in SQL Editor (or apply the new messaging section if the earlier schema is already installed).
2. Create a **private** Storage bucket named `voice-notes`.
3. Apply the Storage policies in the schema. Test uploads and signed playback URLs with two active accounts.
4. The current chat screen uses database refresh to load messages; add Supabase Realtime subscriptions before production.

## 5. LiveKit audio/video calling
1. Create a LiveKit Cloud project and copy its WebSocket URL, API key and API secret.
2. Deploy `supabase/functions/livekit-token` and set Edge Function secrets: `LIVEKIT_URL`, `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET`.
3. Deploy the function and ensure JWT verification is enabled. The function verifies the Supabase user and active profile before issuing a short-lived room token.
4. Add microphone and camera permissions to Android and iOS platform manifests (see below).
5. The call screen currently connects to a LiveKit room and provides mute/camera/end controls. A production call invitation/ringing flow, participant video rendering, call history and group membership authorization still need implementation.

### Android permissions
Add to `android/app/src/main/AndroidManifest.xml` inside the manifest element:
```xml
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
<uses-permission android:name="android.permission.BLUETOOTH" />
```

### iOS permissions
Add to `ios/Runner/Info.plist` inside the dict:
```xml
<key>NSMicrophoneUsageDescription</key>
<string>CME Chats uses the microphone for voice notes and calls.</string>
<key>NSCameraUsageDescription</key>
<string>CME Chats uses the camera for video calls.</string>
```

### FCM incoming call notifications
The app already initializes Firebase Messaging, but a trusted server-side push sender and call invitation state machine are not yet connected. Do not send FCM using service-account credentials from the app. Implement an authenticated Edge Function that sends high-priority call invitations, stores call state, and handles accept/reject/timeout. iOS additionally requires APNs configuration and CallKit integration for a native incoming-call experience.
