import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'screens/auth_gate.dart';

const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (supabaseUrl.isEmpty || supabaseAnonKey.isEmpty) {
    runApp(const SetupRequiredApp());
    return;
  }

  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);

  // Firebase platform configuration files must be added before enabling FCM.
  try {
    await Firebase.initializeApp();
    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);
  } catch (_) {
    // Authentication and core app remain usable while Firebase is configured.
  }

  runApp(const CmeChatsApp());
}

class CmeChatsApp extends StatelessWidget {
  const CmeChatsApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'CME Chats',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF16836F)),
      scaffoldBackgroundColor: const Color(0xFFF7FAF8),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
    ),
    home: const AuthGate(),
  );
}

class SetupRequiredApp extends StatelessWidget {
  const SetupRequiredApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    home: Scaffold(body: Center(child: Padding(
      padding: const EdgeInsets.all(24),
      child: Text('CME Chats setup required. Run with --dart-define=SUPABASE_URL=... and --dart-define=SUPABASE_ANON_KEY=...'),
    ))),
  );
}
