import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'chat_screen.dart';
import 'call_screen.dart';

class HomeScreen extends StatelessWidget {
 const HomeScreen({super.key});
 Future<void> signOut() async => Supabase.instance.client.auth.signOut();
 Future<String> _createCommunityConversation() async {
  final db = Supabase.instance.client; final uid = db.auth.currentUser!.id;
  final row = await db.from('conversations').insert({'title': 'CME Community', 'conversation_type': 'group', 'created_by': uid}).select('id').single();
  await db.from('conversation_members').insert({'conversation_id': row['id'], 'user_id': uid});
  return row['id'] as String;
 }
 @override Widget build(BuildContext context)=>Scaffold(
  appBar:AppBar(title:const Text('CME Chats'),actions:[IconButton(onPressed:signOut,icon:const Icon(Icons.logout),tooltip:'Sign out')]),
  body:ListView(padding:const EdgeInsets.all(18),children:[
   Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:const Color(0xFF145B50),borderRadius:BorderRadius.circular(18)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('NACES • FUOYE CHAPTER',style:TextStyle(color:Colors.white70,fontWeight:FontWeight.bold)),SizedBox(height:8),Text('Learn. Connect. Grow.',style:TextStyle(color:Colors.white,fontSize:24,fontWeight:FontWeight.bold)),SizedBox(height:6),Text('Redefining Education Through Chemistry',style:TextStyle(color:Colors.white70,fontStyle:FontStyle.italic))])),
   const SizedBox(height:20),const Text('Your department community',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:12),
   Card(child:ListTile(leading:const Icon(Icons.forum_outlined,color:Color(0xFF16836F)),title:const Text('Open CME community chat'),subtitle:const Text('Text messages and voice notes'),trailing:const Icon(Icons.chevron_right),onTap:() async { try { final id=await _createCommunityConversation(); if(context.mounted) Navigator.push(context,MaterialPageRoute(builder:(_)=>ChatScreen(conversationId:id,title:'CME Community'))); } catch(e) { if(context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Chat setup required: $e'))); } })),
   Card(child:ListTile(leading:const Icon(Icons.call,color:Color(0xFF16836F)),title:const Text('Start audio group call'),subtitle:const Text('LiveKit-powered audio room'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CallScreen(roomName:'cme-community-audio',title:'CME Community Audio Call'))))),
   Card(child:ListTile(leading:const Icon(Icons.video_call,color:Color(0xFF16836F)),title:const Text('Start video group call'),subtitle:const Text('LiveKit-powered video room'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CallScreen(roomName:'cme-community-video',title:'CME Community Video Call',video:true))))),
   for(final item in [('Department updates',Icons.campaign_outlined),('Reading rooms',Icons.menu_book_outlined),('Assignments & research',Icons.science_outlined),('Departmental payments',Icons.receipt_long_outlined)]) Card(child:ListTile(leading:Icon(item.$2,color:const Color(0xFF16836F)),title:Text(item.$1),trailing:const Icon(Icons.chevron_right),onTap:()=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('${item.$1} module is in a later development milestone.'))))),
   const SizedBox(height:10),const Text('Calls require a configured LiveKit server and secure token function. Your account must be active before using community features.',style:TextStyle(color:Colors.black54,fontSize:12))
  ])
 );
}
