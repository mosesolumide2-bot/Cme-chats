import 'package:flutter/material.dart';
import 'package:livekit_client/livekit_client.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class CallScreen extends StatefulWidget {
  const CallScreen({super.key, required this.roomName, required this.title, this.video = false});
  final String roomName; final String title; final bool video;
  @override
  State<CallScreen> createState() => _CallScreenState();
}
class _CallScreenState extends State<CallScreen> {
  Room? _room; bool _connecting = true; bool _muted = false; bool _camera = false; String? _error;
  @override
  void initState() { super.initState(); _connect(); }
  Future<void> _connect() async {
    try {
      final response = await Supabase.instance.client.functions.invoke('livekit-token', body: {'room_name': widget.roomName, 'participant_name': Supabase.instance.client.auth.currentUser?.id, 'can_publish': true});
      final data = Map<String, dynamic>.from(response.data as Map);
      final url = data['url'] as String; final token = data['token'] as String;
      final room = Room();
      await room.connect(url, token, roomOptions: const RoomOptions(adaptiveStream: true, dynacast: true));
      await room.localParticipant.setMicrophoneEnabled(true);
      if (widget.video) { await room.localParticipant.setCameraEnabled(true); _camera = true; }
      if (mounted) setState(() { _room = room; _connecting = false; });
    } catch (e) { if (mounted) setState(() { _error = e.toString(); _connecting = false; }); }
  }
  Future<void> _endCall() async { await _room?.disconnect(); if (mounted) Navigator.of(context).pop(); }
  @override
  void dispose() { _room?.disconnect(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(backgroundColor: const Color(0xFF102B27), appBar: AppBar(backgroundColor: Colors.transparent, foregroundColor: Colors.white, title: Text(widget.title)), body: Center(child: _connecting ? const CircularProgressIndicator(color: Colors.white) : _error != null ? Padding(padding: const EdgeInsets.all(24), child: Text('Call could not start. Configure the livekit-token Edge Function.\n\n$_error', style: const TextStyle(color: Colors.white), textAlign: TextAlign.center)) : Column(mainAxisAlignment: MainAxisAlignment.center, children: [const CircleAvatar(radius: 48, child: Icon(Icons.person, size: 48)), const SizedBox(height: 18), Text(widget.title, style: const TextStyle(color: Colors.white, fontSize: 22)), const SizedBox(height: 8), const Text('Connected to CME Chats call', style: TextStyle(color: Colors.white70)), const SizedBox(height: 44), Wrap(spacing: 18, children: [IconButton.filled(onPressed: () async { _muted = !_muted; await _room?.localParticipant.setMicrophoneEnabled(!_muted); setState(() {}); }, icon: Icon(_muted ? Icons.mic_off : Icons.mic)), if (widget.video) IconButton.filled(onPressed: () async { _camera = !_camera; await _room?.localParticipant.setCameraEnabled(_camera); setState(() {}); }, icon: Icon(_camera ? Icons.videocam : Icons.videocam_off)), IconButton.filled(style: IconButton.styleFrom(backgroundColor: Colors.red), onPressed: _endCall, icon: const Icon(Icons.call_end))])])));
}
