import 'dart:io';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.conversationId, required this.title});
  final String conversationId;
  final String title;
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _supabase = Supabase.instance.client;
  final _text = TextEditingController();
  final _recorder = AudioRecorder();
  final _player = AudioPlayer();
  bool _recording = false;
  bool _sending = false;
  List<Map<String, dynamic>> _messages = [];

  @override
  void initState() { super.initState(); _loadMessages(); }
  @override
  void dispose() { _text.dispose(); _recorder.dispose(); _player.dispose(); super.dispose(); }

  Future<void> _loadMessages() async {
    try {
      final rows = await _supabase.from('messages').select().eq('conversation_id', widget.conversationId).order('created_at');
      if (mounted) setState(() => _messages = List<Map<String, dynamic>>.from(rows));
    } catch (e) { _notice('Could not load messages. Check that the chat database setup has been applied.'); }
  }

  Future<void> _sendText() async {
    final body = _text.text.trim(); if (body.isEmpty) return;
    setState(() => _sending = true);
    try {
      await _supabase.from('messages').insert({'conversation_id': widget.conversationId, 'sender_id': _supabase.auth.currentUser!.id, 'message_type': 'text', 'body': body});
      _text.clear(); await _loadMessages();
    } catch (e) { _notice('Message could not be sent: $e'); }
    if (mounted) setState(() => _sending = false);
  }

  Future<void> _toggleRecording() async {
    if (_recording) { await _finishRecording(); return; }
    if (!await _recorder.hasPermission()) { _notice('Microphone permission is required.'); return; }
    final dir = await getTemporaryDirectory();
    final path = '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
    await _recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: path);
    if (mounted) setState(() => _recording = true);
  }

  Future<void> _finishRecording() async {
    final path = await _recorder.stop();
    if (mounted) setState(() => _recording = false);
    if (path == null) return;
    final file = File(path); final userId = _supabase.auth.currentUser!.id;
    final objectPath = '$userId/${DateTime.now().millisecondsSinceEpoch}.m4a';
    try {
      await _supabase.storage.from('voice-notes').upload(objectPath, file, fileOptions: const FileOptions(contentType: 'audio/mp4'));
      await _supabase.from('messages').insert({'conversation_id': widget.conversationId, 'sender_id': userId, 'message_type': 'voice', 'media_path': objectPath});
      await _loadMessages();
    } catch (e) { _notice('Voice note upload failed. Check Storage bucket and policies: $e'); }
    if (await file.exists()) await file.delete();
  }

  Future<void> _playVoice(String path) async {
    try {
      final url = await _supabase.storage.from('voice-notes').createSignedUrl(path, 3600);
      await _player.setUrl(url); await _player.play();
    } catch (e) { _notice('Unable to play this voice note: $e'); }
  }
  void _notice(String message) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message))); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.title), actions: [IconButton(tooltip: 'Call', onPressed: () => _notice('Start a call from a participant profile or group call screen.'), icon: const Icon(Icons.call)), IconButton(tooltip: 'Video call', onPressed: () => _notice('Start a video call from a participant profile or group call screen.'), icon: const Icon(Icons.video_call))]),
    body: Column(children: [
      Expanded(child: RefreshIndicator(onRefresh: _loadMessages, child: ListView.builder(padding: const EdgeInsets.all(14), itemCount: _messages.length, itemBuilder: (context, index) {
        final m = _messages[index]; final mine = m['sender_id'] == _supabase.auth.currentUser?.id;
        return Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft, child: Card(color: mine ? const Color(0xFFDDF3E9) : Colors.white, child: Padding(padding: const EdgeInsets.all(12), child: m['message_type'] == 'voice' ? Row(mainAxisSize: MainAxisSize.min, children: [IconButton(onPressed: () => _playVoice(m['media_path'] as String), icon: const Icon(Icons.play_circle_fill)), const Text('Voice note')]) : Text(m['body']?.toString() ?? ''))));
      }))),
      SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(10, 6, 10, 10), child: Row(children: [IconButton(onPressed: _toggleRecording, color: _recording ? Colors.red : const Color(0xFF16836F), icon: Icon(_recording ? Icons.stop_circle : Icons.mic), tooltip: _recording ? 'Stop and send voice note' : 'Record voice note'), Expanded(child: TextField(controller: _text, decoration: const InputDecoration(hintText: 'Write a message...', contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12)))), IconButton(onPressed: _sending ? null : _sendText, icon: const Icon(Icons.send, color: Color(0xFF16836F)))]))),
    ]),
  );
}
