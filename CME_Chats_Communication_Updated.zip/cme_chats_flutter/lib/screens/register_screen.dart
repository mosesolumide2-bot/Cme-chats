import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class RegisterScreen extends StatefulWidget {
 const RegisterScreen({super.key});
 @override State<RegisterScreen> createState()=>_RegisterScreenState();
}
class _RegisterScreenState extends State<RegisterScreen>{
 final name=TextEditingController(), email=TextEditingController(), matric=TextEditingController(), password=TextEditingController();
 String role='student', level='100';
 bool busy=false;
 String? message;
 Future<void> register() async {
  if(name.text.trim().isEmpty || email.text.trim().isEmpty || password.text.length<8){setState(()=>message='Enter your name and email. Password must be at least 8 characters.');return;}
  if(role=='student' && matric.text.trim().isEmpty){setState(()=>message='Students must enter their matriculation number.');return;}
  setState(()=>busy=true);
  try{
   final res=await Supabase.instance.client.auth.signUp(email:email.text.trim(),password:password.text, data:{
    'full_name':name.text.trim(),'requested_role':role,'matric_number':matric.text.trim(),'level':role=='student'?level:null
   });
   setState(()=>message=res.session==null?'Account created. Check your email to confirm it. Your account will remain pending until an administrator verifies it.':'Account created. Await administrator verification.');
  } on AuthException catch(e){setState(()=>message=e.message);}
  catch(_){setState(()=>message='Registration failed. Please try again.');}
  finally{if(mounted)setState(()=>busy=false);}
 }
 @override void dispose(){name.dispose();email.dispose();matric.dispose();password.dispose();super.dispose();}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Create account')),body:SafeArea(child:SingleChildScrollView(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
  const Text('Join CME Chats',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),
  const Text('For Chemistry Education students and lecturers at FUOYE.'),
  const SizedBox(height:20),
  TextField(controller:name,decoration:const InputDecoration(labelText:'Full name')),
  const SizedBox(height:12), TextField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'Email address')),
  const SizedBox(height:12), DropdownButtonFormField(value:role,decoration:const InputDecoration(labelText:'Account type'),items:const [DropdownMenuItem(value:'student',child:Text('Student')),DropdownMenuItem(value:'lecturer',child:Text('Lecturer'))],onChanged:(v)=>setState(()=>role=v!)),
  if(role=='student')...[
   const SizedBox(height:12),TextField(controller:matric,decoration:const InputDecoration(labelText:'Matriculation number')),
   const SizedBox(height:12),DropdownButtonFormField(value:level,decoration:const InputDecoration(labelText:'Academic level'),items:const [DropdownMenuItem(value:'100',child:Text('100 Level')),DropdownMenuItem(value:'200',child:Text('200 Level')),DropdownMenuItem(value:'300',child:Text('300 Level')),DropdownMenuItem(value:'400',child:Text('400 Level'))],onChanged:(v)=>setState(()=>level=v!)),
  ],
  const SizedBox(height:12),TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'Password (minimum 8 characters)')),
  if(message!=null)Padding(padding:const EdgeInsets.symmetric(vertical:12),child:Text(message!,style:const TextStyle(color:Colors.teal))),
  const SizedBox(height:16),FilledButton(onPressed:busy?null:register,child:Text(busy?'Creating account...':'Create account')),
  const SizedBox(height:12),const Text('Registration requests require administrator verification. Do not register as an administrator here.',style:TextStyle(color:Colors.black54,fontSize:12))
 ]))));
}
