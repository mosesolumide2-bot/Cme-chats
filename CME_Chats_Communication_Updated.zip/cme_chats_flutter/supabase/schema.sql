-- CME Chats initial Supabase schema
-- Run in Supabase SQL Editor after creating a new project.
create extension if not exists pgcrypto;

create type public.app_role as enum ('student','lecturer','admin','super_admin');
create type public.account_status as enum ('pending','active','suspended','rejected');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  email text,
  requested_role text not null default 'student' check (requested_role in ('student','lecturer')),
  role public.app_role not null default 'student',
  status public.account_status not null default 'pending',
  matric_number text unique,
  academic_level int check (academic_level in (100,200,300,400)),
  department text not null default 'Department of Chemistry Education',
  institution text not null default 'Federal University Oye-Ekiti',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.device_tokens (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  token text not null unique,
  platform text check (platform in ('android','ios','web')),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
declare requested text; lvl int;
begin
 requested := coalesce(new.raw_user_meta_data->>'requested_role','student');
 lvl := nullif(new.raw_user_meta_data->>'level','')::int;
 insert into public.profiles(id,full_name,email,requested_role,role,matric_number,academic_level)
 values(new.id,coalesce(new.raw_user_meta_data->>'full_name','New CME User'),new.email,
   case when requested in ('student','lecturer') then requested else 'student' end,
   case when requested='lecturer' then 'lecturer'::public.app_role else 'student'::public.app_role end,
   nullif(new.raw_user_meta_data->>'matric_number',''),lvl);
 return new;
end; $$;

create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_active_member()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and status='active'); $$;

create or replace function public.has_admin_role()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role in ('admin','super_admin') and status='active'); $$;

alter table public.profiles enable row level security;
alter table public.device_tokens enable row level security;

create policy "Users can read own profile" on public.profiles for select to authenticated using (id=auth.uid());
create policy "Active members can see active directory" on public.profiles for select to authenticated using (public.is_active_member() and status='active');
-- No client-side profile UPDATE policy is granted in this starter. This prevents
-- users changing their own role or approval status. Add a narrowly scoped profile
-- update function later for editable fields such as display name/avatar.
create policy "Admins can manage profiles" on public.profiles for all to authenticated using (public.has_admin_role()) with check (public.has_admin_role());

create policy "Users manage own device tokens" on public.device_tokens for all to authenticated
using (user_id=auth.uid()) with check (user_id=auth.uid());

-- IMPORTANT SECURITY NOTES:
-- 1. Never allow public sign-up to assign admin/super_admin. Promote trusted admins manually
--    in the SQL editor after verifying their identity:
--    update public.profiles set role='super_admin', status='active' where id='AUTH-USER-UUID';
-- 2. The registration UI requests student/lecturer only. Admin approval should set status='active'.
-- 3. Before production, add chat, room, assignment, payment and receipt tables with their own RLS.
-- 4. Use private Storage buckets and signed URLs for payment evidence and generated receipts.


-- Messaging, voice notes and call metadata
create type public.conversation_kind as enum ('direct','group');
create type public.message_kind as enum ('text','voice','image','file');
create table public.conversations (
  id uuid primary key default gen_random_uuid(), title text not null,
  conversation_type public.conversation_kind not null default 'group',
  created_by uuid not null references public.profiles(id), created_at timestamptz not null default now()
);
create table public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(), primary key(conversation_id,user_id)
);
create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id),
  message_type public.message_kind not null default 'text',
  body text, media_path text, created_at timestamptz not null default now(),
  constraint message_payload_check check (
    (message_type='text' and body is not null and media_path is null) or
    (message_type<>'text' and media_path is not null)
  )
);
create table public.call_logs (
  id uuid primary key default gen_random_uuid(), room_name text not null,
  initiated_by uuid not null references public.profiles(id),
  call_type text not null check(call_type in ('audio','video')),
  call_scope text not null check(call_scope in ('direct','group')),
  status text not null default 'started' check(status in ('started','ended','missed','rejected')),
  started_at timestamptz not null default now(), ended_at timestamptz
);

alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.call_logs enable row level security;

-- SECURITY DEFINER helper avoids recursive RLS evaluation on conversation_members.
create or replace function public.is_conversation_member(target_conversation uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.conversation_members cm where cm.conversation_id=target_conversation and cm.user_id=auth.uid()); $$;

create policy "Active users can read conversations they joined" on public.conversations for select to authenticated
using (public.is_active_member() and public.is_conversation_member(id));
create policy "Active users can create conversations" on public.conversations for insert to authenticated
with check (public.is_active_member() and created_by=auth.uid());
create policy "Members can read membership" on public.conversation_members for select to authenticated
using (public.is_conversation_member(conversation_id));
create policy "Users can join a conversation they create" on public.conversation_members for insert to authenticated
with check (user_id=auth.uid() and exists(select 1 from public.conversations c where c.id=conversation_id and c.created_by=auth.uid()) and public.is_active_member());
create policy "Conversation members can read messages" on public.messages for select to authenticated
using (public.is_conversation_member(messages.conversation_id) and public.is_active_member());
create policy "Members can send messages" on public.messages for insert to authenticated
with check (sender_id=auth.uid() and public.is_active_member() and public.is_conversation_member(messages.conversation_id));
create policy "Users can read own call logs" on public.call_logs for select to authenticated using (initiated_by=auth.uid());
create policy "Active users can create call logs" on public.call_logs for insert to authenticated with check (initiated_by=auth.uid() and public.is_active_member());

-- Create a PRIVATE Storage bucket named voice-notes in Supabase Storage.
-- Storage object names are prefixed with the uploader's auth UID.
create policy "Active users upload own voice notes" on storage.objects for insert to authenticated
with check (bucket_id='voice-notes' and (storage.foldername(name))[1]=auth.uid()::text and public.is_active_member());
create policy "Conversation members read voice notes" on storage.objects for select to authenticated
using (bucket_id='voice-notes' and exists (
  select 1 from public.messages m join public.conversation_members cm on cm.conversation_id=m.conversation_id
  where m.media_path=name and cm.user_id=auth.uid()
));
