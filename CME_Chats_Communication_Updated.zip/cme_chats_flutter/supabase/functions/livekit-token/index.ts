// Deploy with: supabase functions deploy livekit-token
// Set LIVEKIT_URL, LIVEKIT_API_KEY and LIVEKIT_API_SECRET as Edge Function secrets.
// Never put the LiveKit API secret in the Flutter app.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { AccessToken } from 'https://esm.sh/livekit-server-sdk@2';
Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  const auth = req.headers.get('Authorization');
  if (!auth) return new Response('Unauthorized', { status: 401 });
  const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: auth } } });
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) return new Response('Unauthorized', { status: 401 });
  const { data: profile } = await supabase.from('profiles').select('status,full_name').eq('id', user.id).single();
  if (!profile || profile.status !== 'active') return new Response('Active account required', { status: 403 });
  const { room_name } = await req.json();
  if (typeof room_name !== 'string' || !/^[a-zA-Z0-9_-]{3,80}$/.test(room_name)) return new Response('Invalid room name', { status: 400 });
  const apiKey = Deno.env.get('LIVEKIT_API_KEY'); const apiSecret = Deno.env.get('LIVEKIT_API_SECRET'); const url = Deno.env.get('LIVEKIT_URL');
  if (!apiKey || !apiSecret || !url) return new Response('LiveKit secrets are not configured', { status: 503 });
  const token = new AccessToken(apiKey, apiSecret, { identity: user.id, name: profile.full_name });
  token.addGrant({ roomJoin: true, room: room_name, canPublish: true, canSubscribe: true });
  return Response.json({ url, token: await token.toJwt() });
});
